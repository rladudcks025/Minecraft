1.21.11 전용 삽-단검 리소스팩
- 기본 삽 외형 유지
- custom_model_data가 붙은 삽만 단검으로 표시
- 1.21.4+의 새 item model 형식 사용

매핑
- wooden_shovel + custom_model_data 1101 = 나무단검
- stone_shovel + custom_model_data 1102 = 돌단검
- iron_shovel + custom_model_data 1103 = 철단검
- golden_shovel + custom_model_data 1104 = 금단검
- diamond_shovel + custom_model_data 1105 = 다이아단검

최신 give 예시 (1.21.4+)
- /give @p minecraft:wooden_shovel[minecraft:custom_model_data={floats:[1101.0]}]
- /give @p minecraft:stone_shovel[minecraft:custom_model_data={floats:[1102.0]}]
- /give @p minecraft:iron_shovel[minecraft:custom_model_data={floats:[1103.0]}]
- /give @p minecraft:golden_shovel[minecraft:custom_model_data={floats:[1104.0]}]
- /give @p minecraft:diamond_shovel[minecraft:custom_model_data={floats:[1105.0]}]

참고
- 1.21.11은 리소스팩 버전 75.0
- 1.21.4부터 item models는 새 data-driven 형식을 사용
