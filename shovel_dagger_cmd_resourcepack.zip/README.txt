이 팩은 삽 기본 외형을 유지하면서, CustomModelData가 붙은 삽만 단검 외형으로 보이게 만드는 리소스팩입니다.

기본 개념
- 그냥 나무삽 / 돌삽 / 철삽 / 금삽 / 다이아삽 = 원래 삽 모습 유지
- CustomModelData가 붙은 삽 = 단검 모습으로 표시

매핑
- wooden_shovel + CMD 1101 = 나무단검
- stone_shovel + CMD 1102 = 돌단검
- iron_shovel + CMD 1103 = 철단검
- golden_shovel + CMD 1104 = 금단검
- diamond_shovel + CMD 1105 = 다이아단검

예시 명령어 (레거시 NBT 방식)
- /give @p minecraft:wooden_shovel{CustomModelData:1101}
- /give @p minecraft:stone_shovel{CustomModelData:1102}
- /give @p minecraft:iron_shovel{CustomModelData:1103}
- /give @p minecraft:golden_shovel{CustomModelData:1104}
- /give @p minecraft:diamond_shovel{CustomModelData:1105}

중요
- 서버에서 아이템을 지급할 때 플러그인/스크립트에서 CustomModelData 값을 넣어줘야 단검으로 보입니다.
- 그냥 삽을 주면 원래 삽 모습으로 보입니다.
- 서버/플러그인 버전에 따라 적용 방식이 다를 수 있습니다.
